package com.example.yaseen.androidchat;

public class ChatMessage {
    public int left;
    public String message;

    public ChatMessage(int left, String message) {
        super();
        this.left = left;
        this.message = message;
    }
}